#!/usr/bin/env bash

dir=${PWD}
mv $1 "$dir"/books